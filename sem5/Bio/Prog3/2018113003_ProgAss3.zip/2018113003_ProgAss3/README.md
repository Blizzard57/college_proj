# Programming Assignment 3

I am submitting a ipynb as the output is too long and viewing it in a pdf would not be feasible and rather be a hindrance. The fasta files which were taken are also present here even though my code has already taken the sequences it. The complete Needle and Water outputs are given in the notebook itself, which makes the notebook too long.